<?php

namespace Egits\Grid\Controller\Adminhtml\Grid;

use Magento\Framework\Controller\ResultFactory;

class AddRow extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;

    /**
     * @var \Egits\Grid\Model\GridFactory
     */
    private $gridFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Egits\Grid\Model\GridFactory $gridFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Egits\Grid\Model\GridFactory $gridFactory
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->gridFactory = $gridFactory;
    }

    /**
     * Add or Edit Row Data.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $rowId = (int) $this->getRequest()->getParam('id');
        $rowData = $this->gridFactory->create();
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        if ($rowId) {
            $rowData = $rowData->load($rowId);
            $rowTitle = $rowData->getTitle();
            if (!$rowData->getArticleId()) {
                $this->messageManager->addError(__('Row data no longer exists.'));
                $this->_redirect('thecoachsmb/grid/rowdata');
                return;
            }
        }

        $this->coreRegistry->register('row_data', $rowData);

        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $title = $rowId ? __('Edit Row Data ') . $rowTitle : __('Add Row Data');
        $resultPage->getConfig()->getTitle()->prepend($title);

        // Handle image upload logic
        if ($this->getRequest()->isPost()) {
            try {
                $data = $this->getRequest()->getPostValue();
                $rowData->setData($data);

                // Handle image upload
                $imageUploader = $this->_objectManager->create(\Magento\MediaStorage\Model\File\Uploader::class, ['fileId' => 'image']);
                $imageUploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                $imageUploader->setAllowRenameFiles(true);
                $imageUploader->setFilesDispersion(true);

                $mediaDirectory = $this->_objectManager->get(\Magento\Framework\Filesystem::class)->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
                $destinationPath = $mediaDirectory->getAbsolutePath('your_module_directory/images/');
                $imageUploader->save($destinationPath);

                // Save image path to the database
                $rowData->setImage('your_module_directory/images/' . $imageUploader->getUploadedFileName());
                $rowData->save();

                $this->messageManager->addSuccessMessage(__('Row data saved successfully.'));
                $this->_redirect('thecoachsmb/grid/rowdata');
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }

        return $resultPage;
    }

    /**
     * Check if the current user is allowed to access this controller action.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Egits_Grid::add_row');
    }
}
