<?php

namespace Egits\Theme\Block;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Catalog\Model\ProductFactory;
use Magento\Framework\UrlInterface;
use Magento\Framework\Data\Form\FormKey;

class Product extends Template
{
    protected $formKey;
    protected $productCollectionFactory;
    protected $productFactory;

    public function __construct(
        Context $context,
        FormKey $formKey,
        CollectionFactory $productCollectionFactory,
        ProductFactory $productFactory,
        array $data = []
    ) {
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productFactory = $productFactory;
        parent::__construct($context, $data);
    }
    public function addProductToWishlist($productId)
    {
        $formKey = $this->formKey->getFormKey();

    }

    public function getImageUrl($productImage)
    {
        // Get the base media URL using BaseUrlResolver
        $baseMediaUrl = $this->_urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]);

        // Combine the base media URL with the image path
        $imageUrl = $baseMediaUrl . 'catalog/product' . $productImage;
        return $imageUrl;
    }

    public function getAllProducts()
    {
        $categoryId = 28; // Category ID for mens shoes
        $products = $this->productCollectionFactory
            ->create()
            ->addCategoriesFilter(['in' => $categoryId]);
        $productDetails = [];

        foreach ($products as $product) {
            $productId = $product->getId();
            //  var_dump($productId);exit;
            $productDetail = $this->productFactory->create()->load($productId);
            // var_dump($this->productFactory->create()->load($productId));
            //exit;
            $productName = $productDetail->getName();
            $productImage = $productDetail->getImage();
            $productprice = $productDetail->getPrice();
            // $productFormKey = $this->addProductToWishlist($productId);
            // var_dump($productFormKey);exit;
            // Use getImageUrl method to get the image URL
            $productImageUrl = $this->getImageUrl($productImage);
            $productUrl = $productDetail->getUrlKey();
            $productDetails[] = [
                'id' => $productId,
                'name' => $productName,
                'image' => $productImageUrl,
                'url' => $productUrl,
                'price' => $productprice
            ];
        }

        return $productDetails;
    }
}
